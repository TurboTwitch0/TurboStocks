"use strict";

// Vercel detects a root index.js that exports an Express app and runs it as a
// serverless function. Locally, `npm start` still runs backend.js directly.
module.exports = require("./backend");
